"""Envelope constants for COMcheck projects."""

from uuid import uuid4

from comcheck_api.types.core_types import (
    AgWall,
    BgWall,
    Door,
    Envelope,
    Floor,
    Roof,
    Skylight,
    ThermalBridge,
    Window,
)
from comcheck_api.utilities.common import get_random_number

DEFAULT_WINDOW: Window = Window.model_validate(
    {
        "adjacentSpaceBuildingType": "WHOLE_BUILDING_OFFICE",
        "adjacentSpaceType": "ADJACENT_SPACE_EXTERIOR",
        "allowanceType": "ENV_ALLOWANCE_NONE",
        "altExemptType": None,
        "assemblyType": "Window:Default Window",
        "bldgUseKey": str(uuid4()),
        "constructionType": "NON_RESIDENTIAL",
        "description": "",
        "exemptionType": "ENV_EXEMPTION_NONE",
        "frameType": "METAL",
        "glazingMaterialType": "GLASS_GLAZING_MAT",
        "glazingType": "TRIPLE_PANE",
        "grossArea": 300,
        "isSiteShading": False,
        "orientation": "NORTH",
        "perfDataType": "PERF_TYPE_NFRC",
        "preAltPropShgc": 0.25,
        "preAltPropUval": 0.35,
        "productId": "WIN-001",
        "productType": "FACTORY_ASSEMBLED_WINDOW",
        "propProjectionFactor": 0.5,
        "propShgc": 0.25,
        "propUValue": 0.35,
        "propVt": 0.65,
        "solarType": "CLEAR",
        "windowOpenType": "NON_OPERABLE_WINDOW",
        "cavityRValue": 0,
        "continuousRValue": 0,
    }
)

DEFAULT_DOOR: Door = Door.model_validate(
    {
        "adjacentSpaceBuildingType": None,
        "adjacentSpaceType": None,
        "allowanceType": None,
        "altExemptType": None,
        "assemblyType": "Door:Default Door",
        "bldgUseKey": str(uuid4()),
        "cavityRValue": 0,
        "continuousRValue": 0,
        "constructionType": None,
        "description": None,
        "doorEntranceType": "ENTRANCE_DOOR",
        "doorOpenType": "SWINGING_DOOR",
        "doorType": "INSUL_METAL_DOOR",
        "exemptionType": None,
        "frameType": None,
        "glazingMaterialType": None,
        "glazingType": None,
        "grossArea": 23,
        "isSiteShading": None,
        "orientation": "UNSPECIFIED_ORIENTATION",
        "perfDataType": None,
        "preAltPropShgc": 0,
        "preAltPropUval": None,
        "productId": None,
        "productType": None,
        "propProjectionFactor": 0,
        "propShgc": 0,
        "propUValue": 0.37,
        "propVt": None,
        "solarType": None,
    }
)

DEFAULT_SKYLIGHT: Skylight = Skylight.model_validate(
    {
        "adjacentSpaceType": None,
        "allowanceType": None,
        "assemblyType": "Skylight:Default Skylight",
        "bldgUseKey": "",
        "curbType": "NO_CURB_SKYLIGHT",
        "description": "",
        "exemptionType": None,
        "frameType": "METAL",
        "glazingMaterialType": "GLASS_GLAZING_MAT",
        "glazingType": "DOUBLE_PANE_LOWE",
        "grossArea": 100,
        "isSiteShading": None,
        "orientation": "UNSPECIFIED_ORIENTATION",
        "perfDataType": None,
        "preAltPropShgc": 0,
        "productId": None,
        "productType": None,
        "propProjectionFactor": 0,
        "propShgc": 0.6,
        "propUValue": 0.55,
        "propVt": None,
        "solarType": "TINTED",
    }
)

DEFAULT_ROOF: Roof = Roof.model_validate(
    {
        "adjacentSpaceType": None,
        "allowanceType": None,
        "assemblyType": "Roof:Default Roof",
        "bldgUseKey": str(uuid4()),
        "cavityRValue": 0,
        "continuousRValue": 37,
        "description": "",
        "exemptionType": None,
        "grossArea": 6000,
        "highAlbedoRoofReqType": "HA_ROOF_EXEMPTION_VEGETATED",
        "orientation": "UNSPECIFIED_ORIENTATION",
        "propUValue": 0.26,
        "purlinSpacing": 0,
        "roofInsulType": None,
        "roofType": "ABOVE_DECK_ROOF",
        "skylight": [],
        "solarReflectance": 0,
        "solarReflectanceIndex": 0,
        "thermalEmittance": 0,
    }
)

DEFAULT_FLOOR: Floor = Floor.model_validate(
    {
        "adjacentSpaceType": None,
        "allowanceType": None,
        "altExemptType": None,
        "assemblyType": "Floor:Default Floor",
        "bldgUseKey": str(uuid4()),
        "cavityRValue": 0,
        "constructionType": None,
        "continuousRValue": 15,
        "depthOfInsulation": 4,
        "description": "",
        "exemptionType": None,
        "floorExposedFrameType": None,
        "floorType": "HEATED_SLAB_ON_GRADE",
        "grossArea": 320,
        "hasEdgeInsul": None,
        "insulationPosition": "VERTICAL",
        "orientation": "UNSPECIFIED_ORIENTATION",
        "propUValue": 0.72,
        "slabFullInsulBelowMinRValue": 0,
    }
)

DEFAULT_AG_WALL: AgWall = AgWall.model_validate(
    {
        "adjacentSpaceType": None,
        "agWallConstructionDetailsType": "NONE",
        "agWallExteriorFinishDetailsType": None,
        "allowanceType": None,
        "assemblyType": "Ext Wall:Default Exterior Wall",
        "bldgUseKey": str(uuid4()),
        "cavityRValue": 20,
        "cmuType": None,
        "concreteDensity": 0,
        "concreteThickness": 0,
        "continuousRValue": 10,
        "description": "",
        "door": [],
        "effectiveUFactor": 0.054,
        "exemptionType": None,
        "furringType": None,
        "grossArea": 4800,
        "heatCapacity": 0,
        "insulationPosition": None,
        "nextToUncondSpace": None,
        "orientation": "NORTH",
        "otherWallType": "NONE",
        "propUValue": 0.048,
        "thermalBridge": [],
        "thermalBridgeAdjustmentFactor": None,
        "thermalBridgeExceptionType": "THERMAL_BRIDGE_EXCEPTION_NONE",
        "wallType": "METAL_FRAME_24_AG_WALL",
        "window": [],
    }
)

DEFAULT_THERMAL_BRIDGE: ThermalBridge = ThermalBridge.model_validate(
    {
        "chiFactor": 0,
        "id": get_random_number(),
        "numberOfPoints": 0,
        "psiFactor": 0.177,
        "thermalBridgeCategory": "THERMAL_BRIDGE_LINEAR",
        "thermalBridgeComplianceType": "THERMAL_BRIDGE_PRESCRIPTIVE",
        "thermalBridgeLength": 100,
        "thermalBridgeType": "THERMAL_BRIDGE_FLOOR_TO_WALL_INTERSECTION",
    }
)

DEFAULT_BG_WALL: BgWall = BgWall.model_validate(
    {
        "adjacentSpaceBuildingType": None,
        "adjacentSpaceType": None,
        "allowanceType": None,
        "altExemptType": None,
        "assemblyType": "Basement:Default Basement",
        "bldgUseKey": "",
        "cavityRValue": 20,
        "cmuType": None,
        "concreteDensity": 95,  # TODO: Generated value
        "concreteThickness": 6,  # TODO: Generated value, type is not correct in coreTypes
        "constructionType": None,
        "continuousRValue": 10,
        "description": "",
        "door": [],
        "exemptionType": None,
        "furringType": "WOOD_FURRING",
        "grossArea": 3000,
        "heatCapacity": 0,
        "insulationPosition": None,
        "orientation": "NORTH",
        "propUValue": 0.037,
        "wallHeight": 9,
        "wallHeightBelowGrade": 6,
        "wallType": "CONCRETE_BG_WALL",
        "window": [],
    }
)

DEFAULT_ENVELOPE: Envelope = Envelope(
    agWall=[], bgWall=[], roof=[], floor=[], door=[], window=[], skylight=[]
)

# TODO: add values to other assemblies
DEFAULT_ASSEMBLIES = {
    "Window": DEFAULT_WINDOW,
    "Roof": DEFAULT_ROOF,
    "Skylight": DEFAULT_SKYLIGHT,
    "AgWall": DEFAULT_AG_WALL,
    "BgWall": DEFAULT_BG_WALL,
    "Door": DEFAULT_DOOR,
    "Floor": DEFAULT_FLOOR,
}
