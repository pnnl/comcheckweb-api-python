"""Tests for COMcheckClient."""

import os

import pytest
from dotenv import load_dotenv

from comcheck_api.client import COMcheckClient

# Load environment variables
load_dotenv()


@pytest.fixture(scope="module")
def client():
    """Fixture to create and configure COMcheckClient."""
    api_key = os.getenv("COM_API_KEY")
    if not api_key:
        pytest.fail("COM_API_KEY is not set in environment variables.")

    client = COMcheckClient()
    client.set_api_key(api_key)
    return client


def test_fetch_project_list(client: COMcheckClient):
    """Test fetching the project list."""
    project_list = client.list_projects()
    assert isinstance(project_list, list)


def test_fetch_single_project(client: COMcheckClient):
    """Test fetching a single project if any exist."""
    project_list = client.list_projects()

    if project_list and project_list[0].get("_id"):
        project = client.get_project(project_list[0]["_id"])
        assert project is not None
    else:
        # If no projects exist, just pass the test
        assert True
