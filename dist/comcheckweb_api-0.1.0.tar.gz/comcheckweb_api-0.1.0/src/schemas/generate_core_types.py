#!/usr/bin/env python3
"""Generate TypedDict from comCheck.schema.json."""
import subprocess
import sys
from pathlib import Path

# Input and output paths
INPUT_SCHEMA = Path(__file__).parent / "comCheck.schema.json"
OUTPUT_TYPES = Path(__file__).parent.parent / "types" / "core_types.py"

# Ensure output directory exists
OUTPUT_TYPES.parent.mkdir(parents=True, exist_ok=True)

# Run datamodel-codegen CLI
result = subprocess.run(
    [
        "datamodel-codegen",
        "--input",
        str(INPUT_SCHEMA),
        "--input-file-type",
        "jsonschema",
        "--output",
        str(OUTPUT_TYPES),
        "--output-model-type",
        "typing.TypedDict",
        "--target-python-version",
        "3.13",
        "--use-standard-collections",
        "--use-schema-description",
    ],
    check=False,
)

if result.returncode == 0:
    print(f"Generated: {OUTPUT_TYPES}")
else:
    print(f"Generation failed with exit code {result.returncode}", file=sys.stderr)
    sys.exit(result.returncode)
